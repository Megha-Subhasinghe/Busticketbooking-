<?php
$title = 'Rapid Run Transport- A/C Bus Ticket Booking';
//E-Ticketing System For A/C Bus
$supervisor_name = "Sanduni Subhasinghe";
$developer_name = "Sanduni Subhasinghe";
$developer_matric = "16/52HA016";
